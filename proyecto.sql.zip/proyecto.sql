-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 10-11-2024 a las 02:43:05
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `proyecto`
--
CREATE DATABASE IF NOT EXISTS `proyecto` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `proyecto`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentario`
--
-- Creación: 25-09-2024 a las 23:26:40
--

CREATE TABLE `comentario` (
  `id_comentario` int(11) NOT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `id_dashboard` int(11) DEFAULT NULL,
  `texto` text DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACIONES PARA LA TABLA `comentario`:
--   `id_usuario`
--       `usuario` -> `id_usuario`
--   `id_dashboard`
--       `dashboard` -> `id_dashboard`
--

--
-- Volcado de datos para la tabla `comentario`
--

INSERT INTO `comentario` (`id_comentario`, `id_usuario`, `id_dashboard`, `texto`, `fecha`) VALUES
(1, 1, 1, 'prueba', '2024-09-26 00:55:17'),
(2, 2, 2, 'prueba2', '2024-09-26 00:55:17'),
(3, 5, 4, 'Se solicita revision de datos incongruentes del dia 23/09/2024', '2024-09-28 16:24:52'),
(4, 3, 5, 'Se solicita que puedan cambiar la grafica de pastel a grafica de anillo y puedan poner los titulos en negro', '2024-09-28 16:24:52'),
(6, 1, 4, 'Comentario de prueba', '2024-09-28 16:25:19');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dashboard`
--
-- Creación: 26-09-2024 a las 00:46:45
--

CREATE TABLE `dashboard` (
  `id_dashboard` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `Id_DataSet` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACIONES PARA LA TABLA `dashboard`:
--   `Id_DataSet`
--       `dataset` -> `id_dataset`
--

--
-- Volcado de datos para la tabla `dashboard`
--

INSERT INTO `dashboard` (`id_dashboard`, `nombre`, `url`, `Id_DataSet`) VALUES
(1, 'Dashboard1empresaA', 'https/prueba1', 1),
(2, 'Dashboard1EmpresaB', 'httsp/prueba2', 2),
(3, 'Dashboard Ingenia', 'https/dashboardIngenia', 3),
(4, 'Dashboard Ingenia', 'https/dashoboradIngenia', 4),
(5, 'Dashboard Spectrum', 'https/dashbaordSpectrum', 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dataset`
--
-- Creación: 25-09-2024 a las 23:43:57
--

CREATE TABLE `dataset` (
  `id_dataset` int(11) NOT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `url_descarga` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACIONES PARA LA TABLA `dataset`:
--

--
-- Volcado de datos para la tabla `dataset`
--

INSERT INTO `dataset` (`id_dataset`, `nombre`, `descripcion`, `url_descarga`) VALUES
(1, 'datadashboard1empresa1', NULL, 'data1'),
(2, 'datadashboard1empresa2', NULL, 'data2'),
(3, 'Data llamadas Dashboard Ingenia', 'Contiene los datos de llamadas de la campaña de ingenia', 'https/Datallamadas.com'),
(4, 'Data Tickets Dashboard Ingenia', 'Contiene la data de tickets de la campaña de ingenia', NULL),
(5, 'Data Dashboard Llamadas Spectrum', 'contiene la data de llamadas de la campaña Spectrum', 'https//llamadasSpectrum');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empresa`
--
-- Creación: 26-09-2024 a las 00:31:52
--

CREATE TABLE `empresa` (
  `id_empresa` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `Id_Dashboard` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACIONES PARA LA TABLA `empresa`:
--   `Id_Dashboard`
--       `dashboard` -> `id_dashboard`
--

--
-- Volcado de datos para la tabla `empresa`
--

INSERT INTO `empresa` (`id_empresa`, `nombre`, `direccion`, `Id_Dashboard`) VALUES
(1, 'Empresa A', 'Direccion A', 1),
(2, 'Empresa B', 'Direccion B', 2),
(3, 'Ingenia', NULL, 3),
(4, 'Spectrum', NULL, 5),
(6, 'Ingenia', NULL, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `feedback`
--
-- Creación: 09-11-2024 a las 20:56:42
-- Última actualización: 10-11-2024 a las 00:32:02
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `user_response` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACIONES PARA LA TABLA `feedback`:
--

--
-- Volcado de datos para la tabla `feedback`
--

INSERT INTO `feedback` (`id`, `user_response`, `created_at`) VALUES
(1, '', '2024-11-09 22:44:36'),
(2, '', '2024-11-09 22:59:15'),
(3, 'hola, buena', '2024-11-09 23:00:54'),
(4, 'Hola, buena', '2024-11-09 23:02:09'),
(5, 'hola, mala', '2024-11-09 23:02:21'),
(6, 'Hola, buena', '2024-11-09 23:07:39'),
(7, 'hola', '2024-11-09 23:07:44'),
(8, 'hola', '2024-11-09 23:12:09'),
(9, 'hola', '2024-11-09 23:12:36'),
(10, 'hola', '2024-11-10 00:19:51'),
(11, 'Hola, bien', '2024-11-10 00:23:42'),
(12, 'bien', '2024-11-10 00:32:02');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rol`
--
-- Creación: 25-09-2024 a las 23:26:40
--

CREATE TABLE `rol` (
  `id_rol` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACIONES PARA LA TABLA `rol`:
--

--
-- Volcado de datos para la tabla `rol`
--

INSERT INTO `rol` (`id_rol`, `nombre`) VALUES
(1, 'Administrador'),
(2, 'Descargador'),
(3, 'Visualizador');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--
-- Creación: 18-10-2024 a las 04:53:49
--

CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL,
  `nombre` text DEFAULT NULL,
  `mail` text DEFAULT NULL,
  `contra` text DEFAULT NULL,
  `doble_autenticacion` tinyint(1) DEFAULT NULL,
  `fotografia` varchar(255) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `id_empresa` int(11) DEFAULT NULL,
  `id_rol` int(11) DEFAULT NULL,
  `tipo` text DEFAULT NULL,
  `acceso` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACIONES PARA LA TABLA `usuario`:
--   `id_empresa`
--       `empresa` -> `id_empresa`
--   `id_rol`
--       `rol` -> `id_rol`
--

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `nombre`, `mail`, `contra`, `doble_autenticacion`, `fotografia`, `descripcion`, `id_empresa`, `id_rol`, `tipo`, `acceso`) VALUES
(1, 'Usuario01', 'prueba@gmail.com', '1345t66', 1, NULL, NULL, 1, 1, NULL, NULL),
(2, 'usuario2', 'prueba2@gmail.com', '123456', 1, NULL, NULL, 2, 2, NULL, NULL),
(3, 'Angela Martinez', 'am@prueba.com', '123445678', NULL, NULL, 'Tiene acceso a descarga de data, perteneciente a ingenia', 3, 2, NULL, NULL),
(4, 'Luis Lopez', 'zet.grisel@gmail.com', '12345678$A', NULL, NULL, 'Tiene acceso a visualizacion, pertenenciente a ingenia', 3, 3, '', ''),
(5, 'Ana Guevara', 'ag@gmail.com', '43t5093u50q3', NULL, NULL, 'Tiene acceso a descarga de spectrum', 4, 2, NULL, NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `comentario`
--
ALTER TABLE `comentario`
  ADD PRIMARY KEY (`id_comentario`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `id_dashboard` (`id_dashboard`);

--
-- Indices de la tabla `dashboard`
--
ALTER TABLE `dashboard`
  ADD PRIMARY KEY (`id_dashboard`),
  ADD KEY `rol_ibfk_1` (`Id_DataSet`);

--
-- Indices de la tabla `dataset`
--
ALTER TABLE `dataset`
  ADD PRIMARY KEY (`id_dataset`);

--
-- Indices de la tabla `empresa`
--
ALTER TABLE `empresa`
  ADD PRIMARY KEY (`id_empresa`),
  ADD KEY `empresa_ibfk_2` (`Id_Dashboard`);

--
-- Indices de la tabla `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `rol`
--
ALTER TABLE `rol`
  ADD PRIMARY KEY (`id_rol`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `correo` (`mail`) USING HASH,
  ADD KEY `id_empresa` (`id_empresa`),
  ADD KEY `id_rol` (`id_rol`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `comentario`
--
ALTER TABLE `comentario`
  MODIFY `id_comentario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `dashboard`
--
ALTER TABLE `dashboard`
  MODIFY `id_dashboard` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `dataset`
--
ALTER TABLE `dataset`
  MODIFY `id_dataset` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `empresa`
--
ALTER TABLE `empresa`
  MODIFY `id_empresa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `rol`
--
ALTER TABLE `rol`
  MODIFY `id_rol` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `comentario`
--
ALTER TABLE `comentario`
  ADD CONSTRAINT `comentario_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`),
  ADD CONSTRAINT `comentario_ibfk_2` FOREIGN KEY (`id_dashboard`) REFERENCES `dashboard` (`id_dashboard`);

--
-- Filtros para la tabla `dashboard`
--
ALTER TABLE `dashboard`
  ADD CONSTRAINT `rol_ibfk_1` FOREIGN KEY (`Id_DataSet`) REFERENCES `dataset` (`id_dataset`);

--
-- Filtros para la tabla `empresa`
--
ALTER TABLE `empresa`
  ADD CONSTRAINT `empresa_ibfk_2` FOREIGN KEY (`Id_Dashboard`) REFERENCES `dashboard` (`id_dashboard`);

--
-- Filtros para la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`id_empresa`) REFERENCES `empresa` (`id_empresa`),
  ADD CONSTRAINT `usuario_ibfk_2` FOREIGN KEY (`id_rol`) REFERENCES `rol` (`id_rol`);


--
-- Metadatos
--
USE `phpmyadmin`;

--
-- Metadatos para la tabla comentario
--

--
-- Metadatos para la tabla dashboard
--

--
-- Metadatos para la tabla dataset
--

--
-- Metadatos para la tabla empresa
--

--
-- Metadatos para la tabla feedback
--

--
-- Metadatos para la tabla rol
--

--
-- Metadatos para la tabla usuario
--

--
-- Volcado de datos para la tabla `pma__table_uiprefs`
--

INSERT INTO `pma__table_uiprefs` (`username`, `db_name`, `table_name`, `prefs`, `last_update`) VALUES
('root', 'proyecto', 'usuario', '{\"CREATE_TIME\":\"2024-10-16 19:00:07\"}', '2024-10-18 04:53:08');

--
-- Metadatos para la base de datos proyecto
--

--
-- Volcado de datos para la tabla `pma__pdf_pages`
--

INSERT INTO `pma__pdf_pages` (`db_name`, `page_descr`) VALUES
('proyecto', 'BD');

SET @LAST_PAGE = LAST_INSERT_ID();

--
-- Volcado de datos para la tabla `pma__table_coords`
--

INSERT INTO `pma__table_coords` (`db_name`, `table_name`, `pdf_page_number`, `x`, `y`) VALUES
('proyecto', 'comentario', @LAST_PAGE, 432, 27),
('proyecto', 'dashboard', @LAST_PAGE, 682, 178),
('proyecto', 'dataset', @LAST_PAGE, 889, 87),
('proyecto', 'empresa', @LAST_PAGE, 437, 221),
('proyecto', 'rol', @LAST_PAGE, 440, 386),
('proyecto', 'usuario', @LAST_PAGE, 149, 132);

--
-- Volcado de datos para la tabla `pma__savedsearches`
--

INSERT INTO `pma__savedsearches` (`username`, `db_name`, `search_name`, `search_data`) VALUES
('root', 'proyecto', 'Ejemplo 1', '{\"criteriaColumnCount\":3,\"criteriaColumn\":[\"\",\"\",\"\"],\"criteriaSort\":[\"\",\"\",\"\"],\"criteria\":[\"\",\"\",\"\"],\"criteriaAndOrRow\":[\"or\"],\"criteriaAndOrColumn\":[\"and\",\"and\"],\"rows\":0,\"TableList\":[\"comentario\",\"dashboard\",\"dataset\",\"empresa\",\"rol\",\"usuario\"],\"Or0\":[\"\",\"\",\"\"]}'),
('root', 'proyecto', 'Favorito2', '{\"criteriaColumnCount\":3,\"criteriaColumn\":[\"`empresa`.`nombre`\",\"`dashboard`.`nombre`\",\"`dashboard`.`url`\"],\"criteriaSort\":[\"\",\"\",\"\"],\"criteriaShow\":[\"on\",\"on\",\"on\"],\"criteria\":[\"\",\"\",\"\"],\"criteriaAndOrRow\":[\"or\"],\"criteriaAndOrColumn\":[\"and\",\"and\"],\"rows\":0,\"TableList\":[\"comentario\",\"dashboard\",\"dataset\",\"empresa\",\"rol\",\"usuario\"],\"Or0\":[\"\",\"\",\"\"]}'),
('root', 'proyecto', 'prueba1', '{\"criteriaColumnCount\":5,\"criteriaColumn\":[\"`empresa`.`nombre`\",\"`dashboard`.`nombre`\",\"`dashboard`.`url`\",\"`usuario`.`nombre`\",\"`comentario`.`texto`\"],\"criteriaSort\":[\"\",\"\",\"\",\"\",\"\"],\"criteriaShow\":[\"on\",\"on\",\"on\",\"on\",\"on\"],\"criteria\":[\"\",\"\",\"\",\"\",\"\"],\"criteriaAndOrRow\":[\"or\"],\"criteriaAndOrColumn\":[\"and\",\"and\",\"and\",\"and\"],\"rows\":0,\"TableList\":[\"comentario\",\"dashboard\",\"dataset\",\"empresa\",\"rol\",\"usuario\"],\"Or0\":[\"\",\"\",\"\",\"\",\"\"]}'),
('root', 'proyecto', 'Datos Usuario por empresa', '{\"criteriaColumnCount\":6,\"criteriaColumn\":[\"`usuario`.`nombre`\",\"`usuario`.`fotografia`\",\"`empresa`.`nombre`\",\"`rol`.`nombre`\",\"`dashboard`.`nombre`\",\"`dashboard`.`url`\"],\"criteriaSort\":[\"\",\"\",\"\",\"\",\"\",\"\"],\"criteriaShow\":[\"on\",\"on\",\"on\",\"on\",\"on\",\"on\"],\"criteria\":[\"\",\"\",\"\",\"\",\"\",\"\"],\"criteriaAndOrRow\":[\"or\"],\"criteriaAndOrColumn\":[\"and\",\"and\",\"and\",\"and\",\"and\"],\"rows\":0,\"TableList\":[\"comentario\",\"dashboard\",\"dataset\",\"empresa\",\"rol\",\"usuario\"],\"Or0\":[\"\",\"\",\"\",\"\",\"\",\"\"]}');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
